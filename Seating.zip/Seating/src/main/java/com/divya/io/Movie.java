package com.divya.io;


public class Movie {
	
	private String title;
	private String rating;
	private int duration;
	private String synopsis;
	private String releaseDate;
	private String billedCast;
	private String director;
	private String genre;
	private String distributor;
	private String officialWebSite;
	private String session;
	
	
	public String getSession() {
		return session;
	}

	public void setSession(String session) {
		this.session = session;
	}

	public Movie() {
		super();
	}

	public Movie(String title, String rating, int duration, String billedCast,
			String director, String genre) {
		super();
		this.title = title;
		this.rating = rating;
		this.duration = duration;
		this.billedCast = billedCast;
		this.director = director;
		this.genre = genre;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getRating() {
		return rating;
	}

	public void setRating(String rating) {
		this.rating = rating;
	}

	public int getDuration() {
		return duration;
	}

	public void setDuration(int duration) {
		this.duration = duration;
	}

	public String getSynopsis() {
		return synopsis;
	}

	public void setSynopsis(String synopsis) {
		this.synopsis = synopsis;
	}

	public String getReleaseDate() {
		return releaseDate;
	}

	public void setReleaseDate(String releaseDate) {
		this.releaseDate = releaseDate;
	}

	public String getBilledCast() {
		return billedCast;
	}

	public void setBilledCast(String billedCast) {
		this.billedCast = billedCast;
	}

	public String getDirector() {
		return director;
	}

	public void setDirector(String director) {
		this.director = director;
	}

	public String getGenre() {
		return genre;
	}

	public void setGenre(String genre) {
		this.genre = genre;
	}

	public String getDistributor() {
		return distributor;
	}

	public void setDistributor(String distributor) {
		this.distributor = distributor;
	}

	public String getOfficialWebSite() {
		return officialWebSite;
	}

	public void setOfficialWebSite(String officialWebSite) {
		this.officialWebSite = officialWebSite;
	}
	
	
}
