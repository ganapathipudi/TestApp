package com.divya.theater;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.divya.exception.IllegalAssignmentException;
import com.divya.io.Movie;
import com.divya.io.MovieSession;
import com.divya.io.Request;
import com.divya.io.Response;

public class MovieManager {

	private Movie movies[] = new Movie[5];
	private int nextMovieIndex = 0, count = 0;
	private MovieSession sessions[] = new MovieSession[21];
	private String sessionTypes[] = { "MORNING", "EVENING", "NIGHT" };
	private String daysOfWeek[] = { "SUN", "MON", "TUE", "WED", "THUR", "FRI", "SAT" };
	private Theater theater = new Theater();
	private List<Request> requests = new ArrayList<>();

	public Theater getTheater() {
		return theater;
	}

	public List<Request> getRequests() {
		return requests;
	}

	public static void main(String[] args) throws IllegalAssignmentException {

		MovieManager manager = new MovieManager();
		manager.initializeSessions();
		Scanner input = new Scanner(System.in);
		manager.displayMenu();
		int option = input.nextInt();
		while (option != 5) {
			switch (option) {
			case 1:
				manager.registerNewMovie();
				break;
			case 2:
				manager.scheduleMovieSession();
				break;
			case 3:
				manager.bookTickets();
				break;
			case 4:
				manager.displaySessionTimes();
				break;
			default:
				System.out.println("You must enter a valid options");
			} // end switch

			manager.displayMenu();
			option = input.nextInt();
		} // end while

	}

	public void displayMenu() {

		System.out.println("Movie Admin Menu");
		System.out.println("++++++++++++++++++++++++++++++");
		System.out.println("Option 1. Register New Movie ");
		System.out.println("Option 2.Schedule Movie Session");
		System.out.println("Option 3.Book Movie Ticket");
		System.out.println("Option 5. EXIT");

		System.out.print("Please Enter selection: ");

	}

	public boolean registerNewMovie() {
		Movie movie = new Movie();
		Scanner input = new Scanner(System.in);
		System.out.print("Enter the Movie Title");
		movie.setTitle(input.next());

		System.out.print("Enter the Release Date");
		movie.setReleaseDate(input.next());

		System.out.print("Enter the Movie Rating");
		movie.setRating(input.next());

		if (nextMovieIndex >= movies.length) {
			System.out.println("Too many movies in array");
			return false;
		} else {
			movies[nextMovieIndex] = movie;
			nextMovieIndex++;
			count++;
			return true;
		}

	}

	public boolean scheduleMovieSession() throws IllegalAssignmentException {
		if (count != 0) {
			System.out.println("Enter a Theater No of Rows");
			displayMovieListing();
			Scanner input = new Scanner(System.in);
			int i = input.nextInt();
			int temp = count;
			boolean flag = false;
			while (temp != 0) {
				if (temp == i) {
					flag = true;
					break;
				}
				temp--;
			}
			if (flag == true) {
				System.out.println("Enter No of Seats for each Row");

				String index = input.nextLine();
				theater.addRow(index);
				System.out.println("Movie Scheduled");
			}
			return true;
		} else {
			System.out.println("No Movies to schedule!!!!!");
			return false;
		}
	}

	public void displayMovieListing() {
		if (count != 0) {
			for (int i = count; i > 0; i--) {
				System.out.println(i + ". " + movies[i - 1].getTitle());
			}
		} else {
			System.out.printf("\n\nNo Movies to Display!!!!\n\n");
		}
	}

	public void displaySessionTimes() {
		System.out.printf("\n\nsno. Movie   Session\n" + "-------------------------------------\n\n");
		if (count != 0) {
			for (int i = count; i > 0; i--) {
				System.out.println(i + ". " + movies[i - 1].getTitle() + "    " + movies[i - 1].getSession());
			}
		} else {
			System.out.printf("\n\nNo Movies to Display!!!!\n\n");
		}
	}

	public void initializeSessions() {
		int count = 0;
		for (int day = 0; day < daysOfWeek.length; day++) {
			for (int type = 0; type < sessionTypes.length; type++) {
				sessions[count] = new MovieSession(day, type);
				count++;
			}
		}
	}

	public void bookTickets() throws IllegalAssignmentException {
		//manager.displaySessionTimes();
		Scanner input = new Scanner(System.in);
		System.out.println("Enter Name");
		String requestSeats = input.next();
		System.out.println("Enter Requested seats");
		int requestedSeats=input.nextInt();
		Request request = new Request(new Double(Math.random()).intValue()+2, requestSeats,requestedSeats);
		requests.add(request);
		List<Response> responses = theater.process(requests);
		for (Response res : responses)
			System.out.println(res.toString());
	}

}
